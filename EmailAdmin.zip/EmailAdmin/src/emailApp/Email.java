package emailApp;

import java.util.Scanner;

public class Email {
	private String firstName;
	private String lastName;
	private String password;
	private String department;
	private int defaultPWLength = 10;
	private String email;
	private int mailboxCapacity;
	private String alternateEmail;
	private String emailPrifix="Bittrix.xyz";
	
	//Set constructor
	public Email(String firstName,String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.department=setDepartment();
		System.out.println("Email name: "+firstName+" "+ lastName+ "\n Department : " + this.department);
	
		this.password=randomPassword(defaultPWLength); 
		System.out.println("Yor Password is ---: " + this.password);
		
		email= firstName.toLowerCase()+"."+lastName.toLowerCase()+"@"+department+"."+emailPrifix;
		System.out.println("Your email : "+ email);
	
	}
	
	//Ask department ID
	private String setDepartment() {
		
		System.out.println("Enter Departmetn ID\n"+"1.Account\n"+"2.Marketing\n"+"3.Sales\n"+" Number :");
		Scanner in=new Scanner(System.in);
		int depChoice=in.nextInt();
		if(depChoice == 1) {return "Account";}
		else if(depChoice == 2) {return "Marketing";}
		else if(depChoice == 3) {return "Sales";}
		else {return "";}
	}
	
	//Generate Random Password
	private String randomPassword(int length) {
	String setPassWord="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%&*" ;
	char[] password=new char[length];
	for(int i=0;i<length;i++) {
		int rand=(int) (Math.random() * setPassWord.length());
		password[i]=setPassWord.charAt(rand);
		}
		return new String(password);
	}
	
	
}
