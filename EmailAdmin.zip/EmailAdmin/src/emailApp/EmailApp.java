package emailApp;

public class EmailApp {

	public static void main(String[] args) {
		Email E1=new Email("saman","kumara");

	}

	
}
